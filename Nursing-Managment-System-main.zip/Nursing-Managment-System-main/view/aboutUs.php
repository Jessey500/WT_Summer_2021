<!DOCTYPE html>
<html lang="en">
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome to the Nursing Service System </title>
<script> 
$(document).ready(function(){
  
    var div = $("div.login-box");
    div.animate({height: '0px', opacity: '0.4'}, "slow");
    div.animate({width: '0px', opacity: '0.8'}, "slow");
    div.animate({height: '320px', opacity: '0.4'}, "slow");
    div.animate({width: '500px', opacity: '0.8'}, "slow");
 
});
</script> 
</head>
    <div class="topSection">
        <h1 class='topTitle'>Nursing Service System</h1>
        <h2 class='slogan'>- the service you can trust</h2>
        <a href="aboutUs.php" class='aboutPbl'>About us</a><br>
        <a href="contactUs.php" class='contactUs'>Contact Us</a><br>
    </div>
    <div class='navbar'>
        <div class='navCont'>
            <a href="homePage.php" id="nav-cont">Home</a><br>
            <a href="branches.php" id="nav-cont">Branches</a><br>
        </div>
    </div>
    <div class="login-box">
        <h1 style="text-shadow: 1px 2px;">At A Glance</h1>
        <h3 style="text-align:center; text-shadow: 1px 1px;">The Nursing Service System </h3>
        <p style="text-align:center; text-shadow: 1px 1px;">We provide nurse to a patient by taking money. This is a social work also.</p>
       <h2 style="text-align:center;">Come on hire our nurse!!!</h2>
    </div>

    <footer class='footer'>
        Nursing Service System
    </footer>  
          
</body>
</html>