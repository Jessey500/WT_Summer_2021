<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../css/info.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script  src="../jquery/mehedi.js"> </script>
</head>
<body><br><br><br><br>
<h1> write your full 
<input type="text" id="txt" onclick=validateForm()> 
</h1>
<ol>
  
</ol>


<button id="btn2">Append list items</button>

<br>
<button type="button"><a href="adpatienddetail.php"> admin data hare</a></button>
<br>
<br>
<button type="button"><a href="aduserdata.php"> admin data hare</a></button>

</body>
</html>
