<?php
	include('../control/header.php');
	
  

?>

<!DOCTYPE html>
<html>
<head>
	<title>Nurse Profile</title>
	<link rel="stylesheet" href="../css/home.css">
</head>
<body>


<ul>
	
	<li><a href="NurseLogout.php">Log Out</a></li>
	<li><a href="NurseLogin.php">Log In</a></li>
    <li><a href="SetSchedule.php"> Set Schedule </a></li>
	<li><a href="HomePage.php">Home Page</a></li>
    <li><a href="ContactUs.php">Contact</a></li>
    <li><a href="AboutUs.php">About</a></li>

</ul>





</body>
</html>